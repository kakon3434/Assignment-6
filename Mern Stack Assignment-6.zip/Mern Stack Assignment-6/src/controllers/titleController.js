exports.create = async (req, res) => {
    res.send('Create Title API');
};

exports.read = async (req, res) => {
    res.send('Read Title API');
};

exports.delete = async (req, res) => {
    res.send('Delete Title API');
};

exports.update = async (req, res) => {
    res.send('Update Title API');
};
