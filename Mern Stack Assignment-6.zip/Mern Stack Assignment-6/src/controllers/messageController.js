exports.create = async (req, res) => {
    res.send('Create Message API');
};


exports.read = async (req, res) => {
    res.send('Read Message API');
};

exports.delete = async (req, res) => {
    res.send('Delete Message API');
};

exports.update = async (req, res) => {
    res.send('Update Message API');
};