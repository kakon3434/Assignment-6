exports.create = async (req, res) => {
    res.send('Create Comment API');
};


exports.read = async (req, res) => {
    res.send('Read Comment API');
};

exports.delete = async (req, res) => {
    res.send('Delete Comment API');
};

exports.update = async (req, res) => {
    res.send('Update Comment API');
};