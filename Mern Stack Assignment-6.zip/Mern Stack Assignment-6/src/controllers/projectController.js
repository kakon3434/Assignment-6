exports.create = async (req, res) => {
    res.send('Create Project API');
};


exports.read = async (req, res) => {
    res.send('Read Project API');
};

exports.delete = async (req, res) => {
    res.send('Delete Project API');
};

exports.update = async (req, res) => {
    res.send('Update Project API');
};
