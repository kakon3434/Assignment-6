exports.create = async (req, res) => {
    res.send('Create Blog Details API');
};


exports.read = async (req, res) => {
    res.send('Read Blog Details API');
};

exports.delete = async (req, res) => {
    res.send('Delete Blog Details API');
};

exports.update = async (req, res) => {
    res.send('Update Blog Details API');
};
