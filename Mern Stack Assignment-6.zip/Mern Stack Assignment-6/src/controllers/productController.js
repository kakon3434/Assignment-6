exports.create = async (req, res) => {
    res.send('Create Product API');
};


exports.read = async (req, res) => {
    res.send('Read Product API');
};

exports.delete = async (req, res) => {
    res.send('Delete Product API');
};

exports.update = async (req, res) => {
    res.send('Update Product API');
};
