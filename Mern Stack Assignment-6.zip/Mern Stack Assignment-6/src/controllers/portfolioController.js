exports.create = async (req, res) => {
    res.send('Create portfolio API');
};


exports.read = async (req, res) => {
    res.send('Read portfolio API');
};

exports.delete = async (req, res) => {
    res.send('Delete portfolio API');
};

exports.update = async (req, res) => {
    res.send('Update portfolio API');
};