exports.create = async (req, res) => {
    res.send('Create Profit API');
};


exports.read = async (req, res) => {
    res.send('Read Profit API');
};

exports.delete = async (req, res) => {
    res.send('Delete Profit API');
};

exports.update = async (req, res) => {
    res.send('Update Profit API');
};
