exports.create = async (req, res) => {
    res.send('Create Service API');
};


exports.read = async (req, res) => {
    res.send('Read Service API');
};

exports.delete = async (req, res) => {
    res.send('Delete Service API');
};

exports.update = async (req, res) => {
    res.send('Update Service API');
};